import base64, contextlib, io, json, os, secrets, shutil, stat, tempfile, unittest
from unittest import mock
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from endcap import *
from endcap import recovery, core
from endcap.cli import main

FIXED_SECRET = bytes(range(32))


def kit_with(kit_bytes, **changes):
    k = json.loads(kit_bytes)
    for name, val in changes.items():
        if val is DROP:
            k.pop(name)
        else:
            k[name] = val
    return json.dumps(k, sort_keys=True).encode()


DROP = object()


def rb(path):
    with open(path, "rb") as f:
        return f.read()


def snapshot(be):
    return {k: be.get(k) for k in be.list_keys("")}


class TestSecretText(unittest.TestCase):
    def test_round_trip_and_shape(self):
        t = format_secret(FIXED_SECRET)
        self.assertEqual(len(t.replace("-", "")), 56)
        self.assertEqual(len(t.split("-")), 14)
        self.assertTrue(all(len(g) == 4 for g in t.split("-")))
        self.assertEqual(parse_secret(t), FIXED_SECRET)

    def test_tolerates_case_spaces_and_missing_dashes(self):
        t = format_secret(FIXED_SECRET)
        self.assertEqual(parse_secret(t.lower()), FIXED_SECRET)
        self.assertEqual(parse_secret(t.replace("-", " ")), FIXED_SECRET)
        self.assertEqual(parse_secret("  " + t.replace("-", "") + "\n"), FIXED_SECRET)

    def test_alphabet_has_no_ambiguous_digits(self):
        for _ in range(50):
            t = format_secret(secrets.token_bytes(32)).replace("-", "")
            self.assertFalse(set(t) & set("0189"))

    def test_typo_is_caught_by_checksum(self):
        t = format_secret(FIXED_SECRET).replace("-", "")
        for i in (0, 20, 55):
            other = "B" if t[i] != "B" else "C"
            with self.assertRaises(RecoverySecretFormatError):
                parse_secret(t[:i] + other + t[i + 1:])

    def test_malformed_secret_text_rejected(self):
        for bad in ("", "short", "A" * 55, "A" * 57, "0" * 56, "!" * 56, None, 123, b"A" * 56):
            with self.assertRaises(RecoverySecretFormatError):
                parse_secret(bad)

    def test_format_secret_requires_32_bytes(self):
        for bad in (b"", b"x" * 31, b"x" * 33, "x" * 32, None):
            with self.assertRaises(ValueError):
                format_secret(bad)


class TestKit(unittest.TestCase):
    def setUp(self):
        self.key = secrets.token_bytes(32)
        self.secret, self.kit = create_kit(self.key)

    def test_round_trip_returns_the_same_key(self):
        self.assertEqual(open_kit(self.kit, self.secret), self.key)
        self.assertEqual(open_kit(self.kit, self.secret.lower()), self.key)

    def test_kit_contains_no_key_or_secret_in_clear(self):
        self.assertNotIn(self.key, self.kit)
        self.assertNotIn(self.key.hex().encode(), self.kit)
        self.assertNotIn(self.secret.replace("-", "").encode(), self.kit)
        self.assertNotIn(base64.b64encode(self.key), self.kit)

    def test_kit_format_is_exactly_v1(self):
        k = json.loads(self.kit)
        self.assertEqual(set(k), {"format", "version", "kit_id", "alg", "kdf", "wrapped"})
        self.assertEqual((k["format"], k["version"], k["alg"], k["kdf"]),
                         ("endcap-recovery-kit", 1, "AES-256-GCM", "HKDF-SHA256"))
        self.assertLessEqual(len(self.kit), recovery.MAX_KIT_BYTES)

    def test_two_kits_for_one_key_differ_everywhere(self):
        s2, k2 = create_kit(self.key)
        self.assertNotEqual(s2, self.secret)
        self.assertNotEqual(k2, self.kit)
        self.assertNotEqual(json.loads(k2)["kit_id"], json.loads(self.kit)["kit_id"])
        self.assertEqual(open_kit(k2, s2), self.key)
        self.assertEqual(open_kit(self.kit, self.secret), self.key)   # the old kit still works (no revocation)

    def test_bad_owner_key_rejected_at_creation(self):
        for bad in (b"", b"x" * 31, b"x" * 33, None, "x" * 32):
            with self.assertRaises(InvalidKeyError):
                create_kit(bad)

    def test_fingerprint_is_stable_and_key_specific(self):
        self.assertEqual(key_fingerprint(self.key), key_fingerprint(bytes(self.key)))
        self.assertNotEqual(key_fingerprint(self.key), key_fingerprint(secrets.token_bytes(32)))
        self.assertEqual(len(key_fingerprint(self.key)), 16)
        self.assertNotIn(self.key.hex(), key_fingerprint(self.key))


class TestFailClosedSameError(unittest.TestCase):
    """Every kit-side failure must be the SAME class with the SAME message."""

    def setUp(self):
        self.key = secrets.token_bytes(32)
        self.secret, self.kit = create_kit(self.key)

    def assertUniform(self, kit, secret=None, **kw):
        with self.assertRaises(RecoveryFailedError) as cm:
            open_kit(kit, secret or self.secret, **kw)
        self.assertEqual(type(cm.exception), RecoveryFailedError)
        self.assertEqual(str(cm.exception), recovery.FAIL_MESSAGE)
        return cm.exception

    def test_wrong_but_well_formed_secret(self):
        self.assertUniform(self.kit, format_secret(secrets.token_bytes(32)))

    def test_same_message_for_wrong_secret_and_damaged_kit(self):
        e1 = self.assertUniform(self.kit, format_secret(secrets.token_bytes(32)))
        k = json.loads(self.kit); w = bytearray(base64.b64decode(k["wrapped"])); w[20] ^= 1
        e2 = self.assertUniform(kit_with(self.kit, wrapped=base64.b64encode(bytes(w)).decode()))
        self.assertEqual(str(e1), str(e2))
        self.assertIsNone(e1.__cause__)          # no chained detail leaks which check failed

    def test_flipped_bit_anywhere_in_wrapped(self):
        raw = base64.b64decode(json.loads(self.kit)["wrapped"])
        for i in (0, 11, 12, 30, 43, 44, 51, len(raw) - 1):
            w = bytearray(raw); w[i] ^= 0x80
            self.assertUniform(kit_with(self.kit, wrapped=base64.b64encode(bytes(w)).decode()))

    def test_wrong_wrapped_lengths(self):
        raw = base64.b64decode(json.loads(self.kit)["wrapped"])
        for bad in (raw[:-1], raw + b"\x00", raw[:12], b"", raw * 2):
            self.assertUniform(kit_with(self.kit, wrapped=base64.b64encode(bad).decode()))

    def test_wrapped_not_base64(self):
        self.assertUniform(kit_with(self.kit, wrapped="!!!not base64!!!"))
        self.assertUniform(kit_with(self.kit, wrapped=123))

    def test_swapped_kit_id_breaks_the_binding(self):
        self.assertUniform(kit_with(self.kit, kit_id="0" * 32))
        self.assertUniform(kit_with(self.kit, kit_id="G" * 32))
        self.assertUniform(kit_with(self.kit, kit_id=1234))

    def test_wrong_version_and_other_header_fields(self):
        for v in (0, 2, 99, "1", True, 1.0, None):
            self.assertUniform(kit_with(self.kit, version=v))
        self.assertUniform(kit_with(self.kit, format="other"))
        self.assertUniform(kit_with(self.kit, alg="AES-128-GCM"))
        self.assertUniform(kit_with(self.kit, kdf="PBKDF2"))

    def test_missing_or_extra_fields(self):
        for name in ("format", "version", "kit_id", "alg", "kdf", "wrapped"):
            self.assertUniform(kit_with(self.kit, **{name: DROP}))
        self.assertUniform(kit_with(self.kit, extra="x"))

    def test_truncated_garbage_empty_and_oversized(self):
        for bad in (self.kit[: len(self.kit) // 2], self.kit[:-1], b"", b"not json", b"[]", b"null",
                    b"\xff\xfe\x00", b"{}", self.kit + b" " * recovery.MAX_KIT_BYTES, None, "text", 5):
            self.assertUniform(bad)

    def test_kit_for_a_different_key(self):
        other_key = secrets.token_bytes(32)
        other_secret, other_kit = create_kit(other_key)
        self.assertUniform(other_kit)                                        # my secret does not open their kit
        self.assertUniform(self.kit, other_secret)                           # nor theirs mine
        self.assertUniform(self.kit, expected_fingerprint=key_fingerprint(other_key))   # pinned to the wrong key
        self.assertEqual(open_kit(self.kit, self.secret, expected_fingerprint=key_fingerprint(self.key)), self.key)

    def test_bad_expected_fingerprint_types_fail_closed(self):
        for bad in ("", "zz", "0" * 16, 123, b"x"):
            self.assertUniform(self.kit, expected_fingerprint=bad)

    def test_inner_key_binding_is_checked_even_with_the_right_secret(self):
        """Someone who holds the secret still cannot make a kit whose key does not match its fingerprint."""
        secret = FIXED_SECRET
        kit_id, nonce = secrets.token_hex(16), secrets.token_bytes(12)
        k1, k2 = secrets.token_bytes(32), secrets.token_bytes(32)
        pt = k1 + bytes.fromhex(key_fingerprint(k2))                         # key of one, fingerprint of another
        ct = AESGCM(recovery._wrap_key(secret, kit_id)).encrypt(nonce, pt, recovery._aad(kit_id))
        forged = json.dumps({"format": recovery.KIT_FORMAT, "version": 1, "kit_id": kit_id,
                             "alg": recovery.KIT_ALG, "kdf": recovery.KIT_KDF,
                             "wrapped": base64.b64encode(nonce + ct).decode()}, sort_keys=True).encode()
        self.assertUniform(forged, format_secret(secret))

    def test_typo_in_secret_is_a_format_error_not_a_kit_error(self):
        t = self.secret.replace("-", "")
        other = "B" if t[0] != "B" else "C"
        with self.assertRaises(RecoverySecretFormatError):
            open_kit(self.kit, other + t[1:])


class TestKeyFile(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.key = secrets.token_bytes(32)
        self.secret, self.kit = create_kit(self.key)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_restore_writes_exact_key_with_mode_0600(self):
        dest = os.path.join(self.tmp, "owner.key")
        fp = restore_owner_key(self.kit, self.secret, dest)
        self.assertEqual(fp, key_fingerprint(self.key))
        self.assertEqual(load_key(dest), self.key)
        self.assertEqual(stat.S_IMODE(os.stat(dest).st_mode) & 0o077, 0)

    def test_restore_refuses_to_overwrite_and_leaves_existing_file_alone(self):
        dest = os.path.join(self.tmp, "owner.key")
        with open(dest, "wb") as f: f.write(b"precious")
        with self.assertRaises(FileExistsError):
            restore_owner_key(self.kit, self.secret, dest)
        with open(dest, "rb") as f: self.assertEqual(f.read(), b"precious")

    def test_restore_refuses_symlink_destination(self):
        target = os.path.join(self.tmp, "target"); link = os.path.join(self.tmp, "link")
        os.symlink(target, link)                                             # dangling symlink
        with self.assertRaises(FileExistsError):
            restore_owner_key(self.kit, self.secret, link)
        self.assertFalse(os.path.exists(target))

    def test_failed_restore_creates_no_file(self):
        dest = os.path.join(self.tmp, "owner.key")
        with self.assertRaises(RecoveryFailedError):
            restore_owner_key(self.kit, format_secret(secrets.token_bytes(32)), dest)
        with self.assertRaises(RecoveryFailedError):
            restore_owner_key(self.kit, self.secret, dest, expected_fingerprint="0" * 16)
        with self.assertRaises(RecoverySecretFormatError):
            restore_owner_key(self.kit, "garbage", dest)
        self.assertFalse(os.path.lexists(dest))

    def test_write_new_file_cleans_up_on_failure_and_never_overwrites(self):
        dest = os.path.join(self.tmp, "k")
        with mock.patch("os.fsync", side_effect=OSError("disk")):
            with self.assertRaises(OSError):
                recovery.write_new_file(dest, b"x" * 32)
        self.assertFalse(os.path.lexists(dest))
        recovery.write_new_file(dest, b"first")
        with self.assertRaises(FileExistsError):
            recovery.write_new_file(dest, b"second")
        with open(dest, "rb") as f: self.assertEqual(f.read(), b"first")


class TestArchivesUntouched(unittest.TestCase):
    """The point of V1-2: existing archives are recovered by restoring the key, with no archive change."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.be = LocalDirBackend(os.path.join(self.tmp, "store"))
        self.key = secrets.token_bytes(32)
        self.src = os.path.join(self.tmp, "src.bin")
        self.data = os.urandom(5000)
        with open(self.src, "wb") as f: f.write(self.data)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_archive_made_before_any_kit_is_recovered_after_key_loss(self):
        oid = archive(self.be, self.key, self.src, chunk_size=1024)         # no kit exists yet
        before = snapshot(self.be)
        secret, kit = create_kit(self.key)                                  # the kit is made later
        del self.key                                                        # the owner key is "lost"
        dest_key = os.path.join(self.tmp, "owner.key")
        restore_owner_key(kit, secret, dest_key)
        out = os.path.join(self.tmp, "out.bin")
        retrieve(self.be, load_key(dest_key), oid, out)
        with open(out, "rb") as f: self.assertEqual(f.read(), self.data)
        self.assertEqual(snapshot(self.be), before)                         # every stored byte identical

    def test_recovery_operations_never_touch_storage(self):
        oid = archive(self.be, self.key, self.src, chunk_size=1024)
        before = snapshot(self.be)
        secret, kit = create_kit(self.key)
        open_kit(kit, secret)
        restore_owner_key(kit, secret, os.path.join(self.tmp, "k1"))
        with self.assertRaises(RecoveryFailedError):
            open_kit(kit[:-3], secret)
        self.assertEqual(snapshot(self.be), before)
        self.assertEqual(status(self.be, oid), "complete")
        self.assertEqual(verify(self.be, self.key, oid)["size"], 5000)

    def test_wrong_owner_key_still_cannot_read_archive(self):
        oid = archive(self.be, self.key, self.src)
        other_secret, other_kit = create_kit(secrets.token_bytes(32))       # a kit for some OTHER key
        wrong = open_kit(other_kit, other_secret)
        with self.assertRaises(AuthenticationError):
            verify(self.be, wrong, oid)


class TestCLI(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        j = lambda n: os.path.join(self.tmp, n)
        self.store, self.key, self.kit, self.src = j("store"), j("owner.key"), j("owner.recovery-kit"), j("src.bin")
        self.data = os.urandom(3000)
        with open(self.src, "wb") as f: f.write(self.data)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def run_cli(self, *argv, stdin=None):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            if stdin is None:
                rc = main(["--store", self.store, "--key", self.key, *argv])
            else:
                with mock.patch("sys.stdin", io.StringIO(stdin)):
                    rc = main(["--store", self.store, "--key", self.key, *argv])
        return rc, out.getvalue(), err.getvalue()

    def setup_archive_and_kit(self):
        self.assertEqual(self.run_cli("keygen")[0], 0)
        rc, out, _ = self.run_cli("archive", self.src); self.assertEqual(rc, 0)
        self.oid = out.strip()
        rc, out, err = self.run_cli("recovery-init", "--kit", self.kit); self.assertEqual(rc, 0)
        lines = dict(l.split(": ", 1) for l in out.strip().splitlines())
        self.fp, self.secret = lines["fingerprint"], lines["secret"]
        return err

    def test_full_lifecycle_lose_key_then_restore_and_retrieve(self):
        self.setup_archive_and_kit()
        original = rb(self.key)
        os.unlink(self.key)                                                 # key lost
        rc, out, err = self.run_cli("recovery-restore", self.kit, "--secret-stdin", "--fingerprint", self.fp,
                                    "--verify-object", self.oid, stdin=self.secret + "\n")
        self.assertEqual(rc, 0, err)
        self.assertEqual(rb(self.key), original)
        self.assertEqual(stat.S_IMODE(os.stat(self.key).st_mode) & 0o077, 0)
        dest = os.path.join(self.tmp, "back.bin")
        self.assertEqual(self.run_cli("retrieve", self.oid, dest)[0], 0)
        self.assertEqual(rb(dest), self.data)

    def test_secret_is_shown_once_and_never_saved_to_disk(self):
        err = self.setup_archive_and_kit()
        self.assertNotIn(self.secret, err)                                  # guidance goes to stderr, secret to stdout only
        needle = self.secret.replace("-", "").encode()
        for d, _, files in os.walk(self.tmp):
            for n in files:
                with open(os.path.join(d, n), "rb") as f:
                    blob = f.read()
                self.assertNotIn(needle, blob.replace(b"-", b""), n)
        self.assertEqual(stat.S_IMODE(os.stat(self.kit).st_mode) & 0o077, 0)

    def test_init_refuses_to_overwrite_an_existing_kit_and_shows_no_secret(self):
        self.setup_archive_and_kit()
        before = rb(self.kit)
        rc, out, err = self.run_cli("recovery-init", "--kit", self.kit)
        self.assertEqual(rc, 1)
        self.assertNotIn("secret", out)
        self.assertIn("FileExistsError", err)
        self.assertEqual(rb(self.kit), before)

    def test_restore_never_overwrites_a_present_key(self):
        self.setup_archive_and_kit()
        before = rb(self.key)
        rc, out, err = self.run_cli("recovery-restore", self.kit, "--secret-stdin", stdin=self.secret + "\n")
        self.assertEqual(rc, 1); self.assertIn("FileExistsError", err)
        self.assertEqual(rb(self.key), before)

    def test_wrong_secret_gives_uniform_error_and_no_key_file(self):
        self.setup_archive_and_kit(); os.unlink(self.key)
        wrong = format_secret(secrets.token_bytes(32))
        rc, out, err = self.run_cli("recovery-restore", self.kit, "--secret-stdin", stdin=wrong + "\n")
        self.assertEqual(rc, 1)
        self.assertIn("RecoveryFailedError", err); self.assertIn(recovery.FAIL_MESSAGE, err)
        self.assertFalse(os.path.lexists(self.key))

    def test_verify_object_failure_writes_no_key_file(self):
        self.setup_archive_and_kit(); os.unlink(self.key)
        rc, out, err = self.run_cli("recovery-restore", self.kit, "--secret-stdin",
                                    "--verify-object", "0" * 32, stdin=self.secret + "\n")
        self.assertEqual(rc, 1); self.assertIn("ObjectNotFoundError", err)
        self.assertFalse(os.path.lexists(self.key))

    def test_check_validates_without_writing_a_key(self):
        self.setup_archive_and_kit(); os.unlink(self.key)
        rc, out, err = self.run_cli("recovery-check", self.kit, "--secret-stdin", "--fingerprint", self.fp,
                                    stdin=self.secret + "\n")
        self.assertEqual(rc, 0); self.assertIn(self.fp, out)
        self.assertFalse(os.path.lexists(self.key))
        rc, _, err = self.run_cli("recovery-check", self.kit, "--secret-stdin", "--fingerprint", "0" * 16,
                                  stdin=self.secret + "\n")
        self.assertEqual(rc, 1); self.assertIn("RecoveryFailedError", err)

    def test_oversized_kit_file_is_rejected(self):
        self.setup_archive_and_kit()
        big = os.path.join(self.tmp, "big.kit")
        with open(big, "wb") as f: f.write(rb(self.kit) + b" " * 10000)
        rc, _, err = self.run_cli("recovery-check", big, "--secret-stdin", stdin=self.secret + "\n")
        self.assertEqual(rc, 1); self.assertIn("RecoveryFailedError", err)

    def test_missing_kit_file_is_a_clean_error(self):
        rc, _, err = self.run_cli("recovery-check", os.path.join(self.tmp, "nope"), "--secret-stdin", stdin="x\n")
        self.assertEqual(rc, 1); self.assertIn("FileNotFoundError", err)


if __name__ == "__main__":
    unittest.main()
