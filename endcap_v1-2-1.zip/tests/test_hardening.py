"""Regression tests for the ENDCAP V1 hardening patch (limits, metadata validation, blob lengths)."""
import contextlib, json, os, secrets, shutil, tempfile, unittest
from unittest import mock
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from endcap import *
from endcap import core

MiB = 1024 * 1024
SMALL = Limits(max_chunk_size=1000, max_chunk_count=3, max_archive_size=2500)


class CountingBackend(MemoryBackend):
    """Records chunk reads so tests can prove validation happens before any chunk is fetched."""
    def __init__(self): super().__init__(); self.chunk_gets = 0
    def get(self, key):
        if "/c" in key: self.chunk_gets += 1
        return super().get(key)


def forge_manifest(be, owner_key, oid, meta, *, version=1, drop=(), extra=None):
    """Write a manifest whose crypto is VALID (correct wrap, correct AEAD) but whose metadata is whatever
    the test supplies. This is what lets us test structural validation instead of auth failures."""
    data_key = AESGCM.generate_key(256); aes = AESGCM(data_key); wn = secrets.token_bytes(12)
    wrapped = wn + AESGCM(owner_key).encrypt(wn, data_key, b"endcap1|wrap|" + oid.encode())
    m = {"format": core.FORMAT, "version": version, "object_id": oid, "alg": core.ALG,
         "wrapped_key": core._b64(wrapped),
         "meta": core._b64(aes.encrypt(core._META_NONCE, json.dumps(meta).encode(), b"endcap1|meta|" + oid.encode()))}
    for k in drop: m.pop(k)
    m.update(extra or {})
    be.put(f"{oid}/manifest", json.dumps(m).encode())
    return aes


def good_meta(**kw):
    m = {"name": "f", "size": 2500, "chunk_size": 1000, "chunk_count": 3}; m.update(kw); return m


class TestLimitsObject(unittest.TestCase):
    def test_defaults_are_the_documented_pilot_values(self):
        self.assertEqual((MAX_CHUNK_SIZE, MAX_CHUNK_COUNT, MAX_ARCHIVE_SIZE), (16 * MiB, 65_536, 1024 * MiB))
        self.assertEqual(DEFAULT_LIMITS, Limits())

    def test_invalid_limits_rejected(self):
        for field in ("max_chunk_size", "max_chunk_count", "max_archive_size"):
            for bad in (True, False, 0, -1, 1.5, "5", None):
                with self.assertRaises(ValueError, msg=(field, bad)): Limits(**{field: bad})

    def test_metadata_helper_direct(self):
        L = SMALL
        self.assertEqual(core._validate_meta(good_meta(), L)["chunk_count"], 3)
        self.assertEqual(core._validate_meta(good_meta(size=0, chunk_count=1), L)["size"], 0)
        bad = [good_meta(size=True), good_meta(chunk_size=True), good_meta(chunk_count=True),
               good_meta(size=-1), good_meta(chunk_size=0), good_meta(chunk_size=-5), good_meta(chunk_count=0),
               good_meta(chunk_size=1001), good_meta(size=2501, chunk_count=3), good_meta(chunk_count=4),
               good_meta(size=0, chunk_count=2), good_meta(size=0, chunk_count=0),
               good_meta(chunk_count=2), good_meta(size=1001, chunk_count=3),      # too few / too many chunks
               good_meta(size=2.0), good_meta(size="2500"), good_meta(name=5), [], "x", None,
               {k: v for k, v in good_meta().items() if k != "size"}]
        for m in bad:
            with self.assertRaises(MalformedManifestError, msg=m): core._validate_meta(m, L)

    def test_exact_chunk_arithmetic(self):
        L = Limits(max_chunk_size=1000, max_chunk_count=100, max_archive_size=10_000)
        for size, cs, n in ((1, 1000, 1), (999, 1000, 1), (1000, 1000, 1), (1001, 1000, 2), (2000, 1000, 2), (2001, 1000, 3)):
            core._validate_meta(good_meta(size=size, chunk_size=cs, chunk_count=n), L)
            with self.assertRaises(MalformedManifestError):
                core._validate_meta(good_meta(size=size, chunk_size=cs, chunk_count=n + 1), L)
            if n > 1:
                with self.assertRaises(MalformedManifestError):
                    core._validate_meta(good_meta(size=size, chunk_size=cs, chunk_count=n - 1), L)


class Mixin:
    def make_backend(self): raise NotImplementedError

    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.be = self.make_backend(); self.key = secrets.token_bytes(32)
        self.src = os.path.join(self.tmp, "src.bin"); self.dest = os.path.join(self.tmp, "out.bin")

    def tearDown(self): shutil.rmtree(self.tmp, ignore_errors=True)

    def write_src(self, data):
        with open(self.src, "wb") as f: f.write(data)

    def rd(self, p):
        with open(p, "rb") as f: return f.read()

    # 1. empty archive shape
    def test_empty_archive_is_one_16_byte_chunk(self):
        self.write_src(b""); oid = archive(self.be, self.key, self.src)
        chunks = [k for k in self.be.list_keys(oid + "/") if k != f"{oid}/manifest"]
        self.assertEqual(chunks, [core._ckey(oid, 0)]); self.assertEqual(len(self.be.get(chunks[0])), 16)
        retrieve(self.be, self.key, oid, self.dest); self.assertEqual(self.rd(self.dest), b"")

    # 2/3. forged-but-authentic metadata is rejected structurally, before any chunk is fetched
    def test_valid_crypto_invalid_metadata_rejected_before_chunk_fetch(self):
        self.be = CountingBackend(); oid = "1" * 32
        cases = [good_meta(size=True), good_meta(chunk_size=True), good_meta(chunk_count=True), good_meta(size=-1),
                 good_meta(chunk_size=0), good_meta(chunk_count=0), good_meta(chunk_size=17 * MiB),
                 good_meta(size=2 * 1024 * MiB, chunk_size=MiB, chunk_count=2048),
                 good_meta(chunk_count=10**9), good_meta(chunk_count=4), good_meta(size=0, chunk_count=2)]
        for m in cases:
            forge_manifest(self.be, self.key, oid, m)
            for fn in (lambda: verify(self.be, self.key, oid), lambda: retrieve(self.be, self.key, oid, self.dest)):
                with self.assertRaises(MalformedManifestError, msg=m): fn()
        self.assertEqual(self.be.chunk_gets, 0); self.assertFalse(os.path.exists(self.dest))

    def test_fixture_control_valid_metadata_passes_validation(self):
        """Proves the forge fixture is authentic: valid meta gets PAST validation and reaches chunk fetch."""
        oid = "2" * 32; forge_manifest(self.be, self.key, oid, good_meta())
        with self.assertRaises(MissingDataError): verify(self.be, self.key, oid)

    # 4. outer manifest schema
    def test_outer_manifest_exact_keys(self):
        oid = "3" * 32
        for k in sorted(core._MANIFEST_KEYS):
            forge_manifest(self.be, self.key, oid, good_meta(), drop=(k,))
            with self.assertRaises(MalformedManifestError, msg=k): verify(self.be, self.key, oid)
        forge_manifest(self.be, self.key, oid, good_meta(), extra={"surprise": 1})
        with self.assertRaises(MalformedManifestError): verify(self.be, self.key, oid)
        for v in (True, "1", 1.0, None):
            forge_manifest(self.be, self.key, oid, good_meta(), version=v)
            with self.assertRaises(MalformedManifestError, msg=v): verify(self.be, self.key, oid)

    # 5. stored blob lengths
    def test_wrong_stored_lengths_rejected(self):
        self.write_src(os.urandom(2500)); oid = archive(self.be, self.key, self.src, chunk_size=1000)
        mutations = {0: (lambda b: b[:-1], lambda b: b + b"\x00", lambda b: b""),       # non-final
                     2: (lambda b: b[:-1], lambda b: b + b"\x00", lambda b: b[:16])}    # final (516 bytes)
        for i, fns in mutations.items():
            k = core._ckey(oid, i); orig = self.be.get(k)
            for fn in fns:
                self.be.put(k, fn(orig))
                # the message proves the LENGTH check fired (AES-GCM alone would also reject, but with a different message)
                with self.assertRaisesRegex(AuthenticationError, "unexpected stored length"): verify(self.be, self.key, oid)
                with self.assertRaisesRegex(AuthenticationError, "unexpected stored length"): retrieve(self.be, self.key, oid, self.dest)
                self.assertFalse(os.path.exists(self.dest))
            self.be.put(k, orig)
        self.assertEqual(verify(self.be, self.key, oid)["size"], 2500)       # restored archive still verifies
        self.assertEqual(len(self.be.get(core._ckey(oid, 0))), 1016); self.assertEqual(len(self.be.get(core._ckey(oid, 2))), 516)

    def test_empty_chunk_wrong_lengths_rejected(self):
        self.write_src(b""); oid = archive(self.be, self.key, self.src); k = core._ckey(oid, 0); orig = self.be.get(k)
        for bad in (orig[:-1], orig + b"\x00", b""):
            self.be.put(k, bad)
            with self.assertRaisesRegex(AuthenticationError, "unexpected stored length"): verify(self.be, self.key, oid)

    def test_right_length_wrong_bytes_still_fails_authentication(self):
        self.write_src(os.urandom(2500)); oid = archive(self.be, self.key, self.src, chunk_size=1000)
        k = core._ckey(oid, 1); b = bytearray(self.be.get(k)); b[0] ^= 1; self.be.put(k, bytes(b))
        with self.assertRaisesRegex(AuthenticationError, "failed authentication"): verify(self.be, self.key, oid)

    def test_missing_chunk_error_preserved(self):
        self.write_src(os.urandom(2500)); oid = archive(self.be, self.key, self.src, chunk_size=1000)
        self.be.delete(core._ckey(oid, 1))
        with self.assertRaises(MissingDataError): verify(self.be, self.key, oid)

    # 6/7. writer size limit, exact and off-by-one
    def test_exact_size_limit_succeeds_and_one_over_is_rejected(self):
        self.write_src(os.urandom(2500)); oid = archive(self.be, self.key, self.src, chunk_size=1000, limits=SMALL)
        self.assertEqual(verify(self.be, self.key, oid, limits=SMALL), {"size": 2500, "chunks": 3})
        retrieve(self.be, self.key, oid, self.dest, limits=SMALL)
        self.write_src(os.urandom(2501)); oid2 = "4" * 32
        with self.assertRaises(LimitExceededError): archive(self.be, self.key, self.src, chunk_size=1000, limits=SMALL, object_id=oid2)
        self.assertEqual(status(self.be, oid2), "absent")               # pre-check: nothing written at all

    def test_empty_file_succeeds_under_tight_limits(self):
        self.write_src(b""); oid = archive(self.be, self.key, self.src, limits=Limits(1, 1, 1))
        self.assertEqual(verify(self.be, self.key, oid, limits=Limits(1, 1, 1)), {"size": 0, "chunks": 1})

    # 8. chunk count / chunk size boundaries
    def test_chunk_count_boundary(self):
        big = Limits(max_chunk_size=1000, max_chunk_count=3, max_archive_size=10**6)
        self.write_src(os.urandom(3000)); oid = archive(self.be, self.key, self.src, chunk_size=1000, limits=big)
        self.assertEqual(verify(self.be, self.key, oid, limits=big)["chunks"], 3)
        self.write_src(os.urandom(3001)); oid2 = "5" * 32
        with self.assertRaises(LimitExceededError): archive(self.be, self.key, self.src, chunk_size=1000, limits=big, object_id=oid2)
        self.assertEqual(status(self.be, oid2), "absent")

    def test_chunk_size_boundary(self):
        L = Limits(max_chunk_size=1000, max_chunk_count=100, max_archive_size=10**6); self.write_src(os.urandom(2500))
        archive(self.be, self.key, self.src, chunk_size=1000, limits=L)
        with self.assertRaises(LimitExceededError): archive(self.be, self.key, self.src, chunk_size=1001, limits=L)
        for bad in (0, -1, True, 1.5):
            with self.assertRaises(ValueError, msg=bad): archive(self.be, self.key, self.src, chunk_size=bad)

    # 4(writer). incremental enforcement when the pre-check is fooled (source grew after the stat)
    def test_incremental_size_limit_leaves_incomplete_object_no_manifest(self):
        self.write_src(os.urandom(2501)); oid = "6" * 32
        with mock.patch("endcap.core.os.path.getsize", return_value=0):
            with self.assertRaises(LimitExceededError):
                archive(self.be, self.key, self.src, chunk_size=1000, limits=SMALL, object_id=oid)
        self.assertEqual(status(self.be, oid), "incomplete"); self.assertFalse(self.be.exists(core._mkey(oid)))
        self.assertEqual(len(self.be.list_keys(oid + "/")), 2)            # chunks 0,1 written, nothing deleted
        with self.assertRaises(IncompleteArchiveError): verify(self.be, self.key, oid, limits=SMALL)
        with self.assertRaises(IncompleteArchiveError): retrieve(self.be, self.key, oid, self.dest, limits=SMALL)

    def test_incremental_chunk_count_limit_leaves_incomplete_object(self):
        L = Limits(max_chunk_size=1000, max_chunk_count=3, max_archive_size=10**6)
        self.write_src(os.urandom(3500)); oid = "7" * 32
        with mock.patch("endcap.core.os.path.getsize", return_value=0):
            with self.assertRaises(LimitExceededError):
                archive(self.be, self.key, self.src, chunk_size=1000, limits=L, object_id=oid)
        self.assertEqual(status(self.be, oid), "incomplete"); self.assertFalse(self.be.exists(core._mkey(oid)))

    # 9. reader/writer consistency and explicit override
    def test_reader_enforces_the_limits_it_is_given(self):
        L = Limits(max_chunk_size=1000, max_chunk_count=5, max_archive_size=10**6)
        self.write_src(os.urandom(2500)); oid = archive(self.be, self.key, self.src, chunk_size=1000, limits=L)
        self.assertEqual(verify(self.be, self.key, oid)["chunks"], 3)                      # default limits read it fine
        for tight in (Limits(max_chunk_count=2), Limits(max_chunk_size=999), Limits(max_archive_size=2499)):
            with self.assertRaises(MalformedManifestError): verify(self.be, self.key, oid, limits=tight)
            with self.assertRaises(MalformedManifestError): retrieve(self.be, self.key, oid, self.dest, limits=tight)

    def test_explicit_override_above_default_round_trips_only_with_same_limits(self):
        big = Limits(max_chunk_size=32 * MiB); self.write_src(os.urandom(17 * MiB))
        with self.assertRaises(LimitExceededError): archive(self.be, self.key, self.src, chunk_size=17 * MiB)   # default refuses
        oid = archive(self.be, self.key, self.src, chunk_size=17 * MiB, limits=big)
        self.assertEqual(verify(self.be, self.key, oid, limits=big), {"size": 17 * MiB, "chunks": 1})
        retrieve(self.be, self.key, oid, self.dest, limits=big); self.assertEqual(self.rd(self.dest), self.rd(self.src))
        with self.assertRaises(MalformedManifestError): verify(self.be, self.key, oid)                            # default reader refuses

    # 10. rejected writes never produce a committed archive
    def test_rejected_writes_never_commit(self):
        self.write_src(os.urandom(2501)); ids = []
        for patch in (None, mock.patch("endcap.core.os.path.getsize", return_value=0)):
            oid = secrets.token_hex(16); ids.append(oid)
            with (patch or contextlib.nullcontext()):
                with self.assertRaises(LimitExceededError):
                    archive(self.be, self.key, self.src, chunk_size=1000, limits=SMALL, object_id=oid)
        for oid in ids: self.assertNotEqual(status(self.be, oid), "complete"); self.assertFalse(self.be.exists(core._mkey(oid)))


class TestLocal(Mixin, unittest.TestCase):
    def make_backend(self): return LocalDirBackend(os.path.join(self.tmp, "store"))


class TestMemory(Mixin, unittest.TestCase):
    def make_backend(self): return MemoryBackend()


if __name__ == "__main__":
    unittest.main(verbosity=2)
