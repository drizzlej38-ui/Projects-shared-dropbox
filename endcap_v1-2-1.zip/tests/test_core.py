import json, os, secrets, shutil, tempfile, unittest
from endcap import *
from endcap import core


class Flaky(MemoryBackend):
    """Fails on the Nth put to simulate an interrupted upload."""
    def __init__(self, fail_at): super().__init__(); self.n = 0; self.fail_at = fail_at
    def put(self, key, data):
        self.n += 1
        if self.n == self.fail_at:
            raise OSError("simulated write failure")
        super().put(key, data)


class Base:
    def make_backend(self): raise NotImplementedError

    def setUp(self):
        self.tmp = tempfile.mkdtemp(); self.be = self.make_backend()
        self.key = secrets.token_bytes(32)
        self.src = os.path.join(self.tmp, "src.bin")
        self.data = os.urandom(2500)                      # 3 chunks at chunk_size=1000
        with open(self.src, "wb") as f: f.write(self.data)
        self.dest = os.path.join(self.tmp, "out.bin")

    def tearDown(self): shutil.rmtree(self.tmp, ignore_errors=True)

    def arch(self, **kw): return archive(self.be, self.key, self.src, chunk_size=1000, **kw)

    def read(self, p):
        with open(p, "rb") as f: return f.read()

    def flip(self, k):
        b = bytearray(self.be.get(k)); b[0] ^= 1; self.be.put(k, bytes(b))

    # 1 round trip
    def test_round_trip(self):
        oid = self.arch()
        self.assertEqual(status(self.be, oid), "complete")
        self.assertEqual(verify(self.be, self.key, oid), {"size": 2500, "chunks": 3})
        r = retrieve(self.be, self.key, oid, self.dest)
        self.assertEqual(self.read(self.dest), self.data); self.assertEqual(r["name"], "src.bin")

    def test_round_trip_edge_sizes(self):
        for n in (0, 1, 999, 1000, 1001, 2000):
            with open(self.src, "wb") as f: f.write(os.urandom(n))
            oid = self.arch(); out = os.path.join(self.tmp, f"o{n}")
            retrieve(self.be, self.key, oid, out); self.assertEqual(self.read(out), self.read(self.src))

    # 2 wrong key
    def test_wrong_key(self):
        oid = self.arch()
        with self.assertRaises(AuthenticationError): retrieve(self.be, secrets.token_bytes(32), oid, self.dest)
        self.assertFalse(os.path.exists(self.dest))

    # 3 corruption
    def test_tampered_chunk(self):
        oid = self.arch(); self.flip(core._ckey(oid, 1))
        with self.assertRaises(AuthenticationError): retrieve(self.be, self.key, oid, self.dest)
        self.assertFalse(os.path.exists(self.dest)); self.assertEqual(os.listdir(self.tmp).count("out.bin"), 0)
        self.assertFalse([n for n in os.listdir(self.tmp) if n.startswith(".endcap-")])

    def test_tampered_manifest_wrapped_key(self):
        oid = self.arch(); m = json.loads(self.be.get(f"{oid}/manifest"))
        w = bytearray(core._unb64(m["wrapped_key"])); w[20] ^= 1; m["wrapped_key"] = core._b64(bytes(w))
        self.be.put(f"{oid}/manifest", json.dumps(m).encode())
        with self.assertRaises(AuthenticationError): verify(self.be, self.key, oid)

    # 4 missing / truncated / reordered
    def test_missing_chunk(self):
        oid = self.arch(); self.be.delete(core._ckey(oid, 1))
        with self.assertRaises(MissingDataError): verify(self.be, self.key, oid)

    def test_truncated_archive_missing_final_chunk(self):
        oid = self.arch(); self.be.delete(core._ckey(oid, 2))
        with self.assertRaises(MissingDataError): verify(self.be, self.key, oid)

    def test_chunks_swapped(self):
        oid = self.arch(); a, b = self.be.get(core._ckey(oid, 0)), self.be.get(core._ckey(oid, 1))
        self.be.put(core._ckey(oid, 0), b); self.be.put(core._ckey(oid, 1), a)
        with self.assertRaises(AuthenticationError): verify(self.be, self.key, oid)

    def test_chunks_from_other_object_rejected(self):
        a, b = self.arch(), self.arch()
        self.be.put(core._ckey(a, 0), self.be.get(core._ckey(b, 0)))
        with self.assertRaises(AuthenticationError): verify(self.be, self.key, a)

    # 5 interrupted write
    def test_interrupted_upload_never_looks_complete(self):
        self.be = Flaky(fail_at=2)
        with self.assertRaises(OSError): self.arch(object_id="a" * 32)
        self.assertEqual(status(self.be, "a" * 32), "incomplete")
        with self.assertRaises(IncompleteArchiveError): retrieve(self.be, self.key, "a" * 32, self.dest)
        self.be.fail_at = -1                                    # retry same id succeeds
        self.arch(object_id="a" * 32)
        self.assertEqual(verify(self.be, self.key, "a" * 32)["chunks"], 3)

    def test_failure_on_manifest_write_is_incomplete(self):
        self.be = Flaky(fail_at=4)                              # 3 chunks ok, manifest fails
        with self.assertRaises(OSError): self.arch(object_id="b" * 32)
        self.assertEqual(status(self.be, "b" * 32), "incomplete")

    # 6 duplicates / retries
    def test_duplicate_committed_id_refused(self):
        oid = self.arch()
        with self.assertRaises(ObjectExistsError): self.arch(object_id=oid)
        self.assertEqual(verify(self.be, self.key, oid)["size"], 2500)   # original untouched

    def test_two_archives_have_distinct_ids_and_ciphertext(self):
        a, b = self.arch(), self.arch(); self.assertNotEqual(a, b)
        self.assertNotEqual(self.be.get(core._ckey(a, 0)), self.be.get(core._ckey(b, 0)))

    # 7 malformed metadata
    def test_malformed_manifests(self):
        oid = self.arch(); good = json.loads(self.be.get(f"{oid}/manifest"))
        bad = [b"not json", b"[]", b"{}", json.dumps({**good, "version": 99}).encode(),
               json.dumps({**good, "alg": "ROT13"}).encode(), json.dumps({**good, "object_id": "c" * 32}).encode(),
               json.dumps({**good, "wrapped_key": "!!!"}).encode(), json.dumps({**good, "meta": 5}).encode()]
        for raw in bad:
            self.be.put(f"{oid}/manifest", raw)
            with self.assertRaises(MalformedManifestError, msg=raw[:30]): verify(self.be, self.key, oid)

    def test_bad_object_id_and_missing_object(self):
        with self.assertRaises(ValueError): verify(self.be, self.key, "../../etc")
        with self.assertRaises(ObjectNotFoundError): verify(self.be, self.key, "d" * 32)

    # 8 / 9 verify-before-accept and destination safety
    def test_no_output_when_late_chunk_is_bad(self):
        oid = self.arch(); self.flip(core._ckey(oid, 2))           # first 2 chunks are fine
        with self.assertRaises(AuthenticationError): retrieve(self.be, self.key, oid, self.dest)
        self.assertFalse(os.path.exists(self.dest))

    def test_existing_destination_not_overwritten(self):
        oid = self.arch()
        with open(self.dest, "wb") as f: f.write(b"precious")
        with self.assertRaises(DestinationExistsError): retrieve(self.be, self.key, oid, self.dest)
        self.assertEqual(self.read(self.dest), b"precious")
        retrieve(self.be, self.key, oid, self.dest, overwrite=True); self.assertEqual(self.read(self.dest), self.data)

    def test_failed_overwrite_keeps_existing_file(self):
        oid = self.arch(); self.flip(core._ckey(oid, 0))
        with open(self.dest, "wb") as f: f.write(b"precious")
        with self.assertRaises(AuthenticationError): retrieve(self.be, self.key, oid, self.dest, overwrite=True)
        self.assertEqual(self.read(self.dest), b"precious")

    # privacy of stored data
    def test_provider_view_has_no_filename_or_plaintext(self):
        with open(self.src, "wb") as f: f.write(b"SECRET-MARKER" * 200)
        oid = self.arch(); blob = b"".join(self.be.get(k) for k in self.be.list_keys(oid + "/"))
        self.assertNotIn(b"SECRET-MARKER", blob); self.assertNotIn(b"src.bin", blob)

    # 10 key loss is permanent
    def test_key_loss_is_permanent(self):
        oid = self.arch(); lost = self.key; self.key = secrets.token_bytes(32)
        with self.assertRaises(AuthenticationError): retrieve(self.be, self.key, oid, self.dest)
        self.assertFalse(os.path.exists(self.dest))             # documented: no recovery path exists in V1

    def test_key_file_handling(self):
        p = os.path.join(self.tmp, "k"); keygen(p)
        self.assertEqual(len(load_key(p)), 32); self.assertEqual(os.stat(p).st_mode & 0o077, 0)
        with self.assertRaises(FileExistsError): keygen(p)
        with open(p, "wb") as f: f.write(b"short")
        with self.assertRaises(InvalidKeyError): load_key(p)


class TestLocalDir(Base, unittest.TestCase):
    def make_backend(self): return LocalDirBackend(os.path.join(self.tmp, "store"))

    def test_path_traversal_keys_rejected(self):
        for k in ("../x", "a/../b", "/abs", "a b", ""):
            with self.assertRaises(ValueError): self.be.put(k, b"x")


class TestMemory(Base, unittest.TestCase):
    def make_backend(self): return MemoryBackend()


if __name__ == "__main__":
    unittest.main(verbosity=2)
