# AGP V1 local authorization core: implementation spec DRAFT
Not a final token format. Reconcile with SRM.MD, GLOSSARY.MD, AGENT_CARD_SCHEMA.md, DRAGON_RADAR.md first.
Tags: [EST] = in existing project docs as relayed by the owner. [NEW] = proposed here, needs review.

## 1. Existing definitions (preserve) [EST]
- Conceptual string: agp:v1:sha256:[content_hash]:[access_level]:ttl=[seconds]:thresh=[n/m]
- Access levels: PREVIEW_ONLY, READ_ONLY, REMOTE_EDIT.
- content_hash identifies the resource; ttl governs expiry; thresh = n of m triage nodes must validate.
- Principle: resources stay at source, access grants move.
- Owner decisions this session: Ed25519 owner signing key; recipient-signed requests; signing keys separate
  from encryption keys; authorization separate from decryption; fail closed.

## 2. Proposed additions [NEW]
- Grant = canonical bytes of the [EST] string fields plus: issuer_pubkey, recipient_pubkey, grant_id, issued_at,
  operations, delegable=false, signature (Ed25519 over canonical bytes). Exact encoding undecided.
- Request = {grant, operation, resource, nonce, timestamp} signed by the recipient key.
- Gate: one function check(request) -> allow/deny, called by every protected ENDCAP operation. Verifies, in order:
  issuer is a trusted owner key; grant signature; recipient signature; recipient == grant recipient;
  resource match; operation permitted by access level; now < issued_at + ttl; grant not revoked;
  nonce unseen (persisted); threshold satisfiable. Any failure or error = deny, with an audit log entry that
  contains no secrets.
- Local persistent stores: revocation list (by grant_id), seen-nonce store with timestamp window.
- Owner recovery: explicit owner-key path that bypasses grants for the owner's own node, logged and tested.

## 3. Unresolved decisions (need owner/ChatGPT input)
1. Resource id. [EST] says content_hash. ENDCAP deliberately avoids plaintext hashes. Options: (a) use ENDCAP
   random object id, (b) hash of the manifest or ciphertext, (c) accept plaintext hash. Recommend (b) or (a).
2. Access level to operation mapping. Proposed: PREVIEW_ONLY = status/metadata only; READ_ONLY = verify+retrieve;
   REMOTE_EDIT = archive new version. Delete is not covered by any level: owner-only in V1.
3. Threshold. V1 single node can only honor 1/1. Proposed: reject any other thresh value (fail closed) until
   multi-node validation exists. Who counts as a "triage node" is not defined here.
4. Clock. TTL needs trusted time; the tablet clock can be wrong or offline. Accept local clock with skew
   tolerance and document it?
5. Revocation scope. Local list only; a revoked grant can still be honored by any node that has not seen it.
6. Delegation. Docs mention delegable tokens in design discussions; proposed default is non-delegable. Confirm.
7. Recipient trust binding. How does the owner learn a recipient's public key (manual fingerprint exchange in V1)?
8. Grant string vs structured grant. Keep the string as a display/canonical form, or sign a structured object?

## 4. Limits (state in all docs)
AGP gates operations performed by an honest ENDCAP node. It cannot stop anyone who controls the stored bytes
and holds the decryption key. Granting read access to a remote recipient requires a separately designed key
wrap for that recipient; this draft does not provide one.

## 5. Tests required (fail closed)
forged signature, wrong issuer, expired, revoked, wrong recipient, wrong resource, insufficient level,
replayed nonce, bad thresh, malformed grant, request signed by non-recipient, clock skew edges, owner recovery.
