# ENDCAP V1-2: owner-key recovery (lost-key recovery only)

Status: PROPOSED for owner review. Built in a separate copy; `core.py`, `storage.py`, the V1-1 tests and the V1-1 docs are byte-identical to V1-1.
Scope: restore a LOST owner key. This is NOT the AGP owner bypass (that needs the AGP gate, which is not authorized).

## Model (decided by the owner: option A, one offline recovery secret)
- `recovery-init` makes a random 256-bit recovery secret and a small kit file holding the owner key encrypted under it.
- Secret: shown once on the terminal, meant for paper. Never written to disk by this code. Kit: a file kept somewhere ELSE.
- Neither alone recovers anything. Anyone holding BOTH can read every archive (the kit is a second copy of the owner key's power).
- `recovery-restore` opens the kit, optionally authenticates a real archive with the recovered key (`--verify-object`), and only then writes the key file.

## Construction (no custom primitives)
secret (32 random bytes) -> HKDF-SHA256 (salt = kit_id) -> wrap key -> AES-256-GCM over owner_key || 8-byte key fingerprint.
AAD binds the kit id and version. Fresh random kit id and nonce per kit. No password, no KDF stretching: the secret is random, not memorable.
Kit file (JSON, exact fields, versioned): format, version=1, kit_id, alg, kdf, wrapped. Max 4096 bytes.

## Secret text
32 bytes + 3-byte checksum, base32 (A-Z, 2-7; no 0/1/8/9), 56 chars in 14 groups of 4. Case, spaces and dashes are ignored on input.
The checksum only catches typos (about 1 in 16.7 million slip through). It adds no security.

## Failure behaviour
- Every kit-side failure raises the SAME `RecoveryFailedError` with the SAME message: wrong secret, tampered, truncated, malformed, oversized, wrong version, mismatched fields, key/fingerprint mismatch, wrong `--fingerprint`.
- A mistyped secret (bad characters, wrong length, failed checksum) raises `RecoverySecretFormatError`. It is decided from the typed text alone and reveals nothing about any kit. This is the one deliberate difference.
- Restore decrypts first and creates the key file only on success. It never overwrites (including symlinks), creates mode 0600, removes partial files on failure.

## What it does not do
- No archive, manifest or backend changes. Archives made before any kit existed are recovered by restoring the key (tested; stored bytes compared before and after).
- No revocation: an old kit keeps working. No key rotation exists in V1, so if a secret may be exposed the only remedy is a new key plus re-archiving.
- No threshold or multi-party recovery (option B deferred; it needs a vetted secret-sharing library, not custom code).
- No signing-key backup. AGP signing keys are separate and out of scope until AGP is authorized.
- 0600 protects against other users of the device only, not a compromised device or privileged attacker.
- Python cannot reliably wipe the secret from memory.
- Recovery gives full read access to all archives. It is deliberately outside any future AGP grant system.

## Operator checklist
1. `keygen`, archive things. 2. `recovery-init`: copy the fingerprint and the secret to paper. 3. Move the kit file off this device (not next to the paper).
4. Test it now: `recovery-check KIT --fingerprint FP` (hidden prompt). 5. After a loss: `recovery-restore KIT --fingerprint FP --verify-object OID`.
