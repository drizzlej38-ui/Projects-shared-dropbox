# ENDCAP V1 core: design notes (implementation decisions, all PROPOSED for owner review)

## Construction
- AES-256-GCM via the `cryptography` library. No custom primitives.
- Owner key: random 256 bits in a 0600 file. Per-archive random 256-bit data key, wrapped (AES-GCM) under the owner key.
- Signing keys (AGP, Ed25519) are separate and never used for encryption.
- Chunks: nonce = 4 zero bytes + 8-byte chunk index. Safe because each archive has its own fresh data key, so
  (key, nonce) never repeats. Metadata uses nonce 0xFF*12, which no chunk can use.
- AAD binds object id, chunk index and a final-chunk flag, so chunks cannot be reordered, swapped between
  objects, or silently truncated.
- Wrapped-key nonce is random 96-bit under the long-lived owner key; fine for a personal archive, revisit
  (e.g. SIV or key-derivation per object) if one owner key will wrap very large numbers of objects.

## Metadata
- Provider sees: format, version, algorithm, random object id, blob count and sizes, upload timing.
- Protected: filename, plaintext size, chunk size, chunk count. No plaintext hash is stored.
- Object id is random, not a content hash (a plaintext hash would let a provider test "do you hold file X?").

## Commit and failure model
- Manifest is written last and is the commit marker. Blobs without a manifest = "incomplete", never "success".
- Retrieve writes to a 0600 temp file, authenticates every chunk and the total length, then renames into place.
  On any failure the temp file is removed and the destination is untouched. Existing destinations are not
  overwritten without explicit consent.
- Interrupted uploads are not auto-deleted (no destructive defaults). Retrying the same object id overwrites
  uncommitted chunks; a committed id is refused.

## Implementation limits (hardening patch) - settings of THIS CODE, not ENDCAP/AGP protocol rules
- `Limits` object (one shared config) used by archive(), verify() and retrieve(); safe defaults for existing callers:
  MAX_CHUNK_SIZE = 16 MiB, MAX_CHUNK_COUNT = 65,536, MAX_ARCHIVE_SIZE = 1 GiB. Values must be positive ints (bools rejected).
- Archives written with non-default limits may need the same `limits=` passed to verify()/retrieve(); a reader with
  stricter limits rejects them with MalformedManifestError.
- archive() defaults chunk_size to min(1 MiB, max_chunk_size); an explicit chunk_size above the limit raises LimitExceededError.
- Reader validates decrypted metadata BEFORE fetching any chunk: ints only (no bools), 1 <= chunk_size <= max,
  0 <= size <= max, 1 <= chunk_count <= max, size == 0 requires chunk_count == 1, size > 0 requires
  chunk_count == ceil(size / chunk_size) (integer arithmetic). Violations raise MalformedManifestError.
  Authenticated-but-extreme metadata is possible from a buggy or compromised writer, so this boundary is still needed.
- Outer manifest must have exactly: format, version, object_id, alg, wrapped_key, meta. Missing/extra keys and
  non-int (or bool) versions are rejected. Future changes go through a new version number.
- Each stored blob must be exactly expected plaintext length + 16 bytes (empty file: exactly 16). Wrong-size blobs raise
  AuthenticationError before decryption; absent blobs still raise MissingDataError. This is defense in depth: AES-GCM would also reject them.
- Writer enforces the same limits. A stat() pre-check rejects over-limit sources before writing anything; limits are
  also enforced incrementally while reading, in case the file changes after the stat. If an over-limit is found after
  chunks were written, LimitExceededError is raised, NO manifest is written, and the object stays "incomplete" (not auto-deleted).

## KNOWN LIMITATION: hostile-backend memory exhaustion is NOT solved
StorageBackend.get() returns a complete `bytes` object, so a hostile backend can make the process allocate an
arbitrarily large blob before our length check runs. The length check bounds what we decrypt and accept, not what
the backend makes us allocate. A bounded-read or streaming backend interface is deferred (not implemented).

## Failure classes (as tested)
| Situation | Class | Detected as |
|---|---|---|
| Corrupted/reordered/swapped chunk, tampered manifest | Detected; recoverable only from another good copy | AuthenticationError |
| Wrong key | Detected; recoverable with the right key | AuthenticationError (AEAD cannot distinguish from tampering) |
| Missing chunk | Detected; recoverable only from another copy | MissingDataError |
| Interrupted upload | Detected; recoverable by re-archiving from source | IncompleteArchiveError |
| Malformed manifest | Detected | MalformedManifestError |
| Owner key lost | PERMANENT LOSS. No recovery path exists in V1 | AuthenticationError |
| Backend loses data, single copy | PERMANENT LOSS (no redundancy in V1) | MissingDataError |

## Not provided in V1
Authorization (AGP gate), second real backend, redundancy, key rotation, passphrase wrapping, deletion,
bounded reads from hostile backends (see limitation above), concurrency control, side-channel hardening, secure memory wiping.
Prototype property only: a malicious provider can delete or withhold data (availability) and can see sizes and timing.
