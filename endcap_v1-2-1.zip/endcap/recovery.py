"""ENDCAP V1-2 owner-key recovery kit (lost-key recovery only).

Model: one random 256-bit RECOVERY SECRET (shown once, kept offline, e.g. on paper) encrypts a copy of the
owner key into a small KIT FILE. Secret and kit are stored in different places; neither alone opens anything.

  secret --HKDF-SHA256(salt=kit_id)--> wrap key --AES-256-GCM--> kit = Enc(owner_key || key_fingerprint)

Nothing here touches archives, manifests or storage backends. Existing archives are unchanged and are
recovered simply by restoring the owner key. No custom primitives: AES-GCM, HKDF and SHA-256 from the
`cryptography` library / stdlib only. This module is NOT an AGP bypass and contains no authorization logic.

Honest limits: anyone holding BOTH the secret and the kit can recover the owner key (and so read every
archive). 0600 file modes only protect against other users of the device, not a compromised device or a
privileged attacker. A kit cannot be revoked; if a secret may be exposed, V1 has no key rotation to fall
back on. The secret is a Python string/bytes object, so it cannot be reliably wiped from memory.
"""
import base64, hashlib, hmac, json, os, re, secrets
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from .core import EndcapError, InvalidKeyError, _is_int

KIT_FORMAT, KIT_VERSION, KIT_ALG, KIT_KDF = "endcap-recovery-kit", 1, "AES-256-GCM", "HKDF-SHA256"
MAX_KIT_BYTES = 4096
_KIT_KEYS = frozenset({"format", "version", "kit_id", "alg", "kdf", "wrapped"})
_ID_RE = re.compile(r"^[0-9a-f]{32}$")
_SECRET_BYTES, _CHECK_BYTES = 32, 3            # 35 bytes -> exactly 56 base32 characters
_SECRET_CHARS = 56
_FP_BYTES = 8
_WRAPPED_LEN = 12 + 32 + _FP_BYTES + 16        # nonce + owner key + fingerprint + GCM tag
FAIL_MESSAGE = "recovery failed: wrong recovery secret, or the kit is damaged or unsupported"


class RecoveryError(EndcapError): pass


class RecoveryFailedError(RecoveryError):
    """ONE externally visible failure for every kit-side problem: wrong secret, tampered, truncated,
    malformed, unsupported-version, or mismatched-key kit. AEAD cannot tell them apart and we do not try."""


class RecoverySecretFormatError(RecoveryError):
    """The typed secret is not well formed or fails its checksum (a typo). Decided from the secret text
    alone, before the kit is looked at, so it reveals nothing about any kit."""


def _checksum(secret):
    return hashlib.sha256(b"endcap1|recovery-secret-check|" + secret).digest()[:_CHECK_BYTES]


def generate_secret():
    return secrets.token_bytes(_SECRET_BYTES)


def format_secret(secret):
    """32 random bytes + 3-byte typo checksum, base32 (A-Z, 2-7: no 0/1/8/9), in 14 groups of 4."""
    if not isinstance(secret, (bytes, bytearray)) or len(secret) != _SECRET_BYTES:
        raise ValueError("recovery secret must be exactly 32 bytes")
    raw = base64.b32encode(bytes(secret) + _checksum(bytes(secret))).decode()
    return "-".join(raw[i:i + 4] for i in range(0, _SECRET_CHARS, 4))


def parse_secret(text):
    """Inverse of format_secret. Tolerates case, spaces and dashes. The checksum only catches typos;
    it adds no security."""
    if not isinstance(text, str):
        raise RecoverySecretFormatError("recovery secret must be text")
    s = re.sub(r"[\s\-]", "", text).upper()
    if not re.fullmatch(r"[A-Z2-7]{%d}" % _SECRET_CHARS, s):
        raise RecoverySecretFormatError("recovery secret is not well formed (expected 56 characters A-Z, 2-7)")
    raw = base64.b32decode(s)
    secret, chk = raw[:_SECRET_BYTES], raw[_SECRET_BYTES:]
    if not hmac.compare_digest(chk, _checksum(secret)):
        raise RecoverySecretFormatError("recovery secret failed its checksum (typo?)")
    return secret


def key_fingerprint(owner_key):
    """16 hex chars identifying an owner key. SHA-256 of a random 256-bit key reveals nothing about it."""
    return hashlib.sha256(b"endcap1|owner-key-id|" + bytes(owner_key)).hexdigest()[:16]


def _wrap_key(secret, kit_id):
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=bytes.fromhex(kit_id),
                info=b"endcap1|recovery|wrapkey").derive(secret)


def _aad(kit_id):
    return b"endcap1|recovery-kit|v1|" + kit_id.encode()


def create_kit(owner_key):
    """Returns (secret_text, kit_bytes). The caller shows secret_text ONCE and never stores it with the kit.
    The kit is self-tested (opened with the new secret) before being returned."""
    if not isinstance(owner_key, (bytes, bytearray)) or len(owner_key) != 32:
        raise InvalidKeyError("owner key must be 32 bytes")
    owner_key = bytes(owner_key)
    secret = generate_secret()
    kit_id = secrets.token_hex(16)
    nonce = secrets.token_bytes(12)
    pt = owner_key + bytes.fromhex(key_fingerprint(owner_key))
    ct = AESGCM(_wrap_key(secret, kit_id)).encrypt(nonce, pt, _aad(kit_id))
    kit = {"format": KIT_FORMAT, "version": KIT_VERSION, "kit_id": kit_id, "alg": KIT_ALG,
           "kdf": KIT_KDF, "wrapped": base64.b64encode(nonce + ct).decode()}
    kit_bytes = json.dumps(kit, sort_keys=True).encode()
    secret_text = format_secret(secret)
    if open_kit(kit_bytes, secret_text, expected_fingerprint=key_fingerprint(owner_key)) != owner_key:
        raise RecoveryError("internal self-test of the new recovery kit failed; nothing was produced")
    return secret_text, kit_bytes


def _open(kit_bytes, secret):
    if not isinstance(kit_bytes, (bytes, bytearray)) or not 0 < len(kit_bytes) <= MAX_KIT_BYTES:
        raise ValueError("kit size")
    k = json.loads(bytes(kit_bytes))
    if not isinstance(k, dict) or set(k) != _KIT_KEYS:
        raise ValueError("kit fields")
    if not (k["format"] == KIT_FORMAT and k["alg"] == KIT_ALG and k["kdf"] == KIT_KDF
            and isinstance(k["kit_id"], str) and _ID_RE.match(k["kit_id"])
            and isinstance(k["wrapped"], str)):
        raise ValueError("kit field values")
    if not _is_int(k["version"]) or k["version"] != KIT_VERSION:
        raise ValueError("kit version")
    wrapped = base64.b64decode(k["wrapped"], validate=True)
    if len(wrapped) != _WRAPPED_LEN:
        raise ValueError("kit length")
    pt = AESGCM(_wrap_key(secret, k["kit_id"])).decrypt(wrapped[:12], wrapped[12:], _aad(k["kit_id"]))
    key, fp = pt[:32], pt[32:]
    if len(pt) != 32 + _FP_BYTES or not hmac.compare_digest(fp, bytes.fromhex(key_fingerprint(key))):
        raise ValueError("kit key binding")
    return key


def open_kit(kit_bytes, secret_text, expected_fingerprint=None):
    """Return the owner key, or fail closed. Any kit-side problem raises the SAME RecoveryFailedError.
    expected_fingerprint (optional) pins the result to the key you expect (from recovery-init output)."""
    secret = parse_secret(secret_text)          # typo -> RecoverySecretFormatError, independent of the kit
    try:
        key = _open(kit_bytes, secret)
        if expected_fingerprint is not None:
            if not isinstance(expected_fingerprint, str) or not hmac.compare_digest(
                    expected_fingerprint.strip().lower().encode(), key_fingerprint(key).encode()):
                raise ValueError("fingerprint mismatch")
    except Exception:                           # deliberate: one uniform fail-closed error, no oracle
        raise RecoveryFailedError(FAIL_MESSAGE) from None
    return key


def write_new_file(path, data):
    """Create `path` with mode 0600, refusing to overwrite anything (FileExistsError, symlinks included)."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
    except BaseException:
        try:
            os.unlink(path)
        except OSError:
            pass
        raise


def restore_owner_key(kit_bytes, secret_text, dest, expected_fingerprint=None):
    """Decrypt first, create the key file only on success. Refuses to overwrite an existing file."""
    key = open_kit(kit_bytes, secret_text, expected_fingerprint)
    write_new_file(dest, key)
    return key_fingerprint(key)
