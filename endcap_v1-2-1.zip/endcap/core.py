"""ENDCAP V1 core. AES-256-GCM (cryptography library), chunked, one random data key per archive,
data key wrapped by an owner key. No custom primitives.

Visible to the storage provider: format/version/alg, object id, number and sizes of blobs.
Protected (encrypted in manifest): filename, plaintext size, chunk size, chunk count.
No plaintext hash is stored anywhere. Authorization (AGP) is NOT in this module by design.
"""
import base64, json, os, re, secrets, tempfile
from dataclasses import dataclass
from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from .storage import BlobNotFound

FORMAT, VERSION, ALG = "endcap-archive", 1, "AES-256-GCM"
DEFAULT_CHUNK = 1 << 20
TAG_LEN = 16                          # AES-GCM authentication tag appended to every stored blob

# Pilot IMPLEMENTATION limits. These are settings of this code, NOT ENDCAP/AGP protocol rules.
# An archive written with non-default limits may need the same limits supplied to verify()/retrieve().
MAX_CHUNK_SIZE = 16 * 1024 * 1024         # 16 MiB
MAX_CHUNK_COUNT = 65_536
MAX_ARCHIVE_SIZE = 1 * 1024 * 1024 * 1024  # 1 GiB

_MANIFEST_KEYS = frozenset({"format", "version", "object_id", "alg", "wrapped_key", "meta"})


def _is_int(x):
    """True for real ints only: Python's bool is an int subclass and is rejected."""
    return isinstance(x, int) and not isinstance(x, bool)


@dataclass(frozen=True)
class Limits:
    """One shared bounds object used by archive(), verify() and retrieve()."""
    max_chunk_size: int = MAX_CHUNK_SIZE
    max_chunk_count: int = MAX_CHUNK_COUNT
    max_archive_size: int = MAX_ARCHIVE_SIZE

    def __post_init__(self):
        for name in ("max_chunk_size", "max_chunk_count", "max_archive_size"):
            v = getattr(self, name)
            if not _is_int(v) or v < 1:
                raise ValueError(f"{name} must be a positive integer (booleans are not accepted)")


DEFAULT_LIMITS = Limits()
_OID_RE = re.compile(r"^[0-9a-f]{32}$")
_META_NONCE = b"\xff" * 12            # chunk nonces are 4 zero bytes + 8-byte index, so never equal


class EndcapError(Exception): pass
class InvalidKeyError(EndcapError): pass
class AuthenticationError(EndcapError):
    """Wrong key OR modified data. AEAD deliberately cannot tell these apart."""
class MissingDataError(EndcapError): pass
class IncompleteArchiveError(EndcapError): pass
class ObjectNotFoundError(EndcapError): pass
class ObjectExistsError(EndcapError): pass
class MalformedManifestError(EndcapError): pass
class DestinationExistsError(EndcapError): pass
class LimitExceededError(EndcapError):
    """Writer side: the source or chunking parameters exceed the configured Limits."""


def keygen(path):
    """Create a new random 256-bit owner key file (mode 0600). Refuses to overwrite."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(secrets.token_bytes(32))


def load_key(path):
    with open(path, "rb") as f:
        k = f.read()
    if len(k) != 32:
        raise InvalidKeyError("owner key file must be exactly 32 bytes")
    return k


def _check_oid(oid):
    if not isinstance(oid, str) or not _OID_RE.match(oid):
        raise ValueError("object id must be 32 lowercase hex characters")


def _mkey(oid): return f"{oid}/manifest"
def _ckey(oid, i): return f"{oid}/c{i:08d}"
def _nonce(i): return b"\x00" * 4 + i.to_bytes(8, "big")


def _chunk_aad(oid, i, final):
    return b"endcap1|chunk|" + oid.encode() + i.to_bytes(8, "big") + (b"\x01" if final else b"\x00")


def _b64(b): return base64.b64encode(b).decode()
def _unb64(s):
    try:
        return base64.b64decode(s, validate=True)
    except Exception:
        raise MalformedManifestError("bad base64 in manifest")


def archive(backend, owner_key, src_path, *, chunk_size=None, object_id=None, limits=None):
    """Encrypt src_path into the backend. The manifest is written LAST and is the commit marker:
    no manifest means the archive is incomplete and is never reported as successful.

    Limits are enforced while reading the source. If a limit is discovered after some chunks were
    already written (e.g. the source grew while being read), LimitExceededError is raised, NO manifest
    is written, and the object is left 'incomplete' (nothing is auto-deleted)."""
    limits = limits or DEFAULT_LIMITS
    if len(owner_key) != 32:
        raise InvalidKeyError("owner key must be 32 bytes")
    if chunk_size is None:      # same 1 MiB default as before, but never above a caller's max_chunk_size
        chunk_size = min(DEFAULT_CHUNK, limits.max_chunk_size)
    if not _is_int(chunk_size) or chunk_size < 1:
        raise ValueError("chunk_size must be a positive integer")
    if chunk_size > limits.max_chunk_size:
        raise LimitExceededError(f"chunk_size {chunk_size} exceeds max_chunk_size {limits.max_chunk_size}")
    oid = object_id or secrets.token_hex(16)
    _check_oid(oid)
    if backend.exists(_mkey(oid)):
        raise ObjectExistsError("object id already committed; refusing to overwrite")
    # Cheap pre-check so the common over-limit case writes nothing at all. The incremental checks
    # below remain authoritative because the file could change after this stat.
    declared = os.path.getsize(src_path)
    if declared > limits.max_archive_size:
        raise LimitExceededError(f"source is {declared} bytes; max_archive_size is {limits.max_archive_size}")
    if max(1, -(-declared // chunk_size)) > limits.max_chunk_count:
        raise LimitExceededError(f"source would need more than max_chunk_count ({limits.max_chunk_count}) chunks")
    data_key = AESGCM.generate_key(256)
    aes = AESGCM(data_key)
    size, count = 0, 0
    with open(src_path, "rb") as f:
        cur = f.read(chunk_size)
        while True:
            if size + len(cur) > limits.max_archive_size:
                raise LimitExceededError("source exceeds max_archive_size while reading")
            if count + 1 > limits.max_chunk_count:
                raise LimitExceededError("source exceeds max_chunk_count while reading")
            nxt = f.read(chunk_size)
            final = nxt == b""
            backend.put(_ckey(oid, count), aes.encrypt(_nonce(count), cur, _chunk_aad(oid, count, final)))
            size += len(cur); count += 1
            if final:
                break
            cur = nxt
    meta = json.dumps({"name": os.path.basename(src_path), "size": size,
                       "chunk_size": chunk_size, "chunk_count": count}).encode()
    wnonce = secrets.token_bytes(12)
    wrapped = wnonce + AESGCM(owner_key).encrypt(wnonce, data_key, b"endcap1|wrap|" + oid.encode())
    manifest = {"format": FORMAT, "version": VERSION, "object_id": oid, "alg": ALG,
                "wrapped_key": _b64(wrapped),
                "meta": _b64(aes.encrypt(_META_NONCE, meta, b"endcap1|meta|" + oid.encode()))}
    backend.put(_mkey(oid), json.dumps(manifest, sort_keys=True).encode())
    return oid


def status(backend, object_id):
    """'complete' | 'incomplete' (blobs but no manifest) | 'absent'. Needs no key."""
    _check_oid(object_id)
    if backend.exists(_mkey(object_id)):
        return "complete"
    return "incomplete" if backend.list_keys(object_id + "/") else "absent"


def _validate_meta(meta, limits):
    """Structural validation of DECRYPTED metadata. Runs before any chunk is fetched.
    Returns a clean dict; raises MalformedManifestError on any violation."""
    if not isinstance(meta, dict):
        raise MalformedManifestError("metadata is not an object")
    try:
        size, cs, count, name = meta["size"], meta["chunk_size"], meta["chunk_count"], meta["name"]
    except KeyError:
        raise MalformedManifestError("metadata is missing a required field")
    if not (_is_int(size) and _is_int(cs) and _is_int(count)) or not isinstance(name, str):
        raise MalformedManifestError("metadata field has the wrong type")
    if not 1 <= cs <= limits.max_chunk_size:
        raise MalformedManifestError("chunk_size out of range")
    if not 0 <= size <= limits.max_archive_size:
        raise MalformedManifestError("size out of range")
    if not 1 <= count <= limits.max_chunk_count:
        raise MalformedManifestError("chunk_count out of range")
    expected = 1 if size == 0 else -(-size // cs)          # integer ceil division
    if count != expected:
        raise MalformedManifestError("chunk_count inconsistent with size and chunk_size")
    return {"name": name, "size": size, "chunk_size": cs, "chunk_count": count}


def _load(backend, owner_key, oid, limits):
    _check_oid(oid)
    if len(owner_key) != 32:
        raise InvalidKeyError("owner key must be 32 bytes")
    try:
        raw = backend.get(_mkey(oid))
    except BlobNotFound:
        if backend.list_keys(oid + "/"):
            raise IncompleteArchiveError("archive has data but no manifest (interrupted upload)")
        raise ObjectNotFoundError("no such archive object")
    try:
        m = json.loads(raw)
    except Exception:
        raise MalformedManifestError("manifest is not valid")
    if not isinstance(m, dict) or set(m) != _MANIFEST_KEYS:
        raise MalformedManifestError("manifest must contain exactly the V1 fields")
    if not (m["format"] == FORMAT and m["object_id"] == oid and m["alg"] == ALG
            and isinstance(m["wrapped_key"], str) and isinstance(m["meta"], str)):
        raise MalformedManifestError("manifest fields invalid")
    if not _is_int(m["version"]):
        raise MalformedManifestError("manifest version must be an integer")
    if m["version"] != VERSION:
        raise MalformedManifestError(f"unsupported manifest version {m['version']}")
    wrapped = _unb64(m["wrapped_key"])
    if len(wrapped) < 12 + 32 + 16:
        raise MalformedManifestError("wrapped key too short")
    try:
        data_key = AESGCM(owner_key).decrypt(wrapped[:12], wrapped[12:], b"endcap1|wrap|" + oid.encode())
        aes = AESGCM(data_key)
        meta = json.loads(aes.decrypt(_META_NONCE, _unb64(m["meta"]), b"endcap1|meta|" + oid.encode()))
    except InvalidTag:
        raise AuthenticationError("wrong key or modified manifest")
    except ValueError:
        raise MalformedManifestError("metadata is not valid")
    return aes, _validate_meta(meta, limits)


def _expected_plain_len(meta, i):
    cs, count, size = meta["chunk_size"], meta["chunk_count"], meta["size"]
    return cs if i < count - 1 else size - cs * (count - 1)


def _decrypt_chunks(backend, aes, oid, meta):
    count = meta["chunk_count"]
    for i in range(count):
        try:
            blob = backend.get(_ckey(oid, i))
        except BlobNotFound:
            raise MissingDataError(f"chunk {i} of {count} is missing")
        # NOTE: backend.get() has already returned the whole blob, so this check bounds what we DECRYPT,
        # not what a hostile backend made us allocate. A bounded-read interface is deferred.
        if len(blob) != _expected_plain_len(meta, i) + TAG_LEN:
            raise AuthenticationError(f"chunk {i} has an unexpected stored length")
        try:
            yield aes.decrypt(_nonce(i), blob, _chunk_aad(oid, i, i == count - 1))
        except InvalidTag:
            raise AuthenticationError(f"chunk {i} failed authentication (corrupted, reordered or wrong key)")


def verify(backend, owner_key, object_id, *, limits=None):
    """Authenticate every chunk without writing anything. Returns {'size','chunks'}."""
    aes, meta = _load(backend, owner_key, object_id, limits or DEFAULT_LIMITS)
    total = sum(len(p) for p in _decrypt_chunks(backend, aes, object_id, meta))
    if total != meta["size"]:
        raise AuthenticationError("plaintext length does not match manifest")
    return {"size": total, "chunks": meta["chunk_count"]}


def retrieve(backend, owner_key, object_id, dest, *, overwrite=False, limits=None):
    """Recover to dest. Output appears at dest only after every chunk is authenticated and the
    length checks out; on any failure the temp file is removed and dest is untouched."""
    if os.path.lexists(dest) and not overwrite:
        raise DestinationExistsError("destination exists; pass overwrite=True to replace it")
    aes, meta = _load(backend, owner_key, object_id, limits or DEFAULT_LIMITS)
    d = os.path.dirname(os.path.abspath(dest))
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".endcap-")     # created 0600
    try:
        total = 0
        with os.fdopen(fd, "wb") as f:
            for part in _decrypt_chunks(backend, aes, object_id, meta):
                f.write(part); total += len(part)
            if total != meta["size"]:
                raise AuthenticationError("plaintext length does not match manifest")
            f.flush(); os.fsync(f.fileno())
        if os.path.lexists(dest) and not overwrite:
            raise DestinationExistsError("destination appeared during recovery")
        os.replace(tmp, dest)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return {"size": total, "chunks": meta["chunk_count"], "name": meta["name"]}
