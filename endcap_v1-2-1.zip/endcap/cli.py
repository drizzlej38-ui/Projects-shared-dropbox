import argparse, getpass, sys
from . import core, recovery
from .storage import LocalDirBackend


def _read_secret(args):
    if args.secret_stdin:
        return sys.stdin.readline().strip()
    return getpass.getpass("Recovery secret (input hidden): ")


def _read_kit(path):
    with open(path, "rb") as f:
        return f.read(recovery.MAX_KIT_BYTES + 1)      # one extra byte so an oversized kit is rejected, not truncated


def main(argv=None):
    p = argparse.ArgumentParser(prog="endcap")
    p.add_argument("--store", default="endcap_store", help="storage directory (local backend)")
    p.add_argument("--key", default="owner.key", help="owner key file")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("keygen")
    a = sub.add_parser("archive"); a.add_argument("file")
    r = sub.add_parser("retrieve"); r.add_argument("object_id"); r.add_argument("dest")
    r.add_argument("--overwrite", action="store_true")
    v = sub.add_parser("verify"); v.add_argument("object_id")
    s = sub.add_parser("status"); s.add_argument("object_id")
    ri = sub.add_parser("recovery-init", help="create a recovery kit for the owner key; prints the secret ONCE")
    ri.add_argument("--kit", default="owner.recovery-kit")
    rc = sub.add_parser("recovery-check", help="test a kit + secret without writing any key")
    rc.add_argument("kit"); rc.add_argument("--secret-stdin", action="store_true")
    rc.add_argument("--fingerprint", help="expected owner key fingerprint (from recovery-init)")
    rr = sub.add_parser("recovery-restore", help="restore the owner key to --key (never overwrites)")
    rr.add_argument("kit"); rr.add_argument("--secret-stdin", action="store_true")
    rr.add_argument("--fingerprint", help="expected owner key fingerprint (from recovery-init)")
    rr.add_argument("--verify-object", metavar="OBJECT_ID",
                    help="authenticate this archive in --store with the restored key BEFORE writing the key file")
    args = p.parse_args(argv)
    try:
        if args.cmd == "keygen":
            core.keygen(args.key); print(f"created {args.key} (BACK IT UP: losing it means permanent loss)")
        elif args.cmd == "archive":
            print(core.archive(LocalDirBackend(args.store), core.load_key(args.key), args.file))
        elif args.cmd == "retrieve":
            r = core.retrieve(LocalDirBackend(args.store), core.load_key(args.key), args.object_id, args.dest,
                              overwrite=args.overwrite)
            print(f"ok: {r['size']} bytes in {r['chunks']} chunk(s)")
        elif args.cmd == "verify":
            r = core.verify(LocalDirBackend(args.store), core.load_key(args.key), args.object_id)
            print(f"ok: {r['size']} bytes in {r['chunks']} chunk(s)")
        elif args.cmd == "status":
            print(core.status(LocalDirBackend(args.store), args.object_id))
        elif args.cmd == "recovery-init":
            key = core.load_key(args.key)
            secret, kit = recovery.create_kit(key)
            recovery.write_new_file(args.kit, kit)             # kit first: if it cannot be saved, no secret is shown
            print(f"kit written: {args.kit}", file=sys.stderr)
            print("Write the secret below on paper NOW. It is shown once and is not saved anywhere.", file=sys.stderr)
            print("Keep the secret and the kit file in DIFFERENT places. Anyone with both can read every archive.", file=sys.stderr)
            print(f"fingerprint: {recovery.key_fingerprint(key)}")
            print(f"secret: {secret}")
        elif args.cmd == "recovery-check":
            key = recovery.open_kit(_read_kit(args.kit), _read_secret(args), args.fingerprint)
            print(f"ok: kit opens; owner key fingerprint {recovery.key_fingerprint(key)}")
        elif args.cmd == "recovery-restore":
            key = recovery.open_kit(_read_kit(args.kit), _read_secret(args), args.fingerprint)
            if args.verify_object:
                res = core.verify(LocalDirBackend(args.store), key, args.verify_object)
                print(f"archive {args.verify_object} verified with the restored key ({res['size']} bytes)")
            recovery.write_new_file(args.key, key)
            print(f"restored {args.key}; fingerprint {recovery.key_fingerprint(key)}")
    except (core.EndcapError, FileNotFoundError, FileExistsError, ValueError) as e:
        print(f"error: {type(e).__name__}: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
