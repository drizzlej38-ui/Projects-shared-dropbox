"""Storage interface. Backends are treated as UNTRUSTED for confidentiality and integrity.

Semantics every backend must provide:
  put(key, data)  - atomic per key: readers see the old blob or the whole new blob, never a partial one.
                    Overwriting an existing key is allowed (retries are idempotent at this layer).
  get(key)        - returns bytes, or raises BlobNotFound.
  exists(key)     - bool.
  delete(key)     - removes the blob; deleting a missing key is a no-op.
  list_keys(prefix) - sorted keys beginning with prefix.
Keys look like "<object_id>/<name>"; backends must reject keys outside [A-Za-z0-9_.-/] or containing "..".
"""
import os, re, tempfile
from abc import ABC, abstractmethod

_KEY_RE = re.compile(r"^[A-Za-z0-9_.\-]+(/[A-Za-z0-9_.\-]+)*$")


class BlobNotFound(KeyError):
    pass


def _check_key(key):
    if not isinstance(key, str) or not _KEY_RE.match(key) or ".." in key:
        raise ValueError("invalid storage key")


class StorageBackend(ABC):
    @abstractmethod
    def put(self, key, data): ...
    @abstractmethod
    def get(self, key): ...
    @abstractmethod
    def exists(self, key): ...
    @abstractmethod
    def delete(self, key): ...
    @abstractmethod
    def list_keys(self, prefix=""): ...


class LocalDirBackend(StorageBackend):
    def __init__(self, root):
        self.root = os.path.abspath(root)
        os.makedirs(self.root, exist_ok=True)

    def _path(self, key):
        _check_key(key)
        p = os.path.abspath(os.path.join(self.root, *key.split("/")))
        if not p.startswith(self.root + os.sep):
            raise ValueError("invalid storage key")
        return p

    def put(self, key, data):
        p = self._path(key)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(p), prefix=".tmp-")
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, p)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    def get(self, key):
        try:
            with open(self._path(key), "rb") as f:
                return f.read()
        except FileNotFoundError:
            raise BlobNotFound(key)

    def exists(self, key):
        return os.path.isfile(self._path(key))

    def delete(self, key):
        try:
            os.unlink(self._path(key))
        except FileNotFoundError:
            pass

    def list_keys(self, prefix=""):
        out = []
        for d, _, files in os.walk(self.root):
            for n in files:
                if n.startswith(".tmp-"):
                    continue
                rel = os.path.relpath(os.path.join(d, n), self.root).replace(os.sep, "/")
                if rel.startswith(prefix):
                    out.append(rel)
        return sorted(out)


class MemoryBackend(StorageBackend):
    """In-memory backend. Used to exercise the interface; NOT the Phase E 'second backend'."""
    def __init__(self):
        self.blobs = {}

    def put(self, key, data):
        _check_key(key); self.blobs[key] = bytes(data)

    def get(self, key):
        _check_key(key)
        if key not in self.blobs:
            raise BlobNotFound(key)
        return self.blobs[key]

    def exists(self, key):
        _check_key(key); return key in self.blobs

    def delete(self, key):
        _check_key(key); self.blobs.pop(key, None)

    def list_keys(self, prefix=""):
        return sorted(k for k in self.blobs if k.startswith(prefix))
