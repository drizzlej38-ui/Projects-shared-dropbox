"""ENDCAP V1 prototype: owner-keyed, chunked, authenticated archive over a pluggable store."""
from .core import (archive, retrieve, verify, status, keygen, load_key,
                   EndcapError, AuthenticationError, MissingDataError, IncompleteArchiveError,
                   ObjectNotFoundError, ObjectExistsError, MalformedManifestError,
                   DestinationExistsError, InvalidKeyError, LimitExceededError,
                   Limits, DEFAULT_LIMITS, MAX_CHUNK_SIZE, MAX_CHUNK_COUNT, MAX_ARCHIVE_SIZE)
from .recovery import (create_kit, open_kit, restore_owner_key, key_fingerprint, format_secret, parse_secret,
                       RecoveryError, RecoveryFailedError, RecoverySecretFormatError)
from .storage import StorageBackend, LocalDirBackend, MemoryBackend, BlobNotFound
__version__ = "0.2.0-proto"
