# ENDCAP V1-2 prototype (local archive core + owner-key recovery kit)
Status: prototype. V1-2 (123 tests) run in a Linux container with Python 3.12 / cryptography 46.0.6; V1-1 (81 tests) reported by the owner as run on Termux (Python 3.14, cryptography 50.0.2). V1-2 recovery tests NOT yet run on Termux. Note: requirements.txt pins cryptography<48 but that Termux install was 50.0.2.

Setup:   pip install -r requirements.txt     (Termux: try `pkg install python-cryptography` first)
Test:    python -m unittest discover -s tests -v
Use:     python -m endcap.cli keygen                      # creates owner.key (back it up!)
         python -m endcap.cli archive FILE                # prints object id
         python -m endcap.cli verify OBJECT_ID
         python -m endcap.cli retrieve OBJECT_ID OUT      # refuses to overwrite OUT unless --overwrite
         python -m endcap.cli status OBJECT_ID            # complete | incomplete | absent (no key needed)
Recovery (V1-2, see docs/ENDCAP_RECOVERY_DESIGN.md; lost-key recovery only, archives unchanged):
         python -m endcap.cli recovery-init              # writes owner.recovery-kit, prints fingerprint + secret ONCE (write it on paper)
         python -m endcap.cli recovery-check KIT --fingerprint FP
         python -m endcap.cli recovery-restore KIT --fingerprint FP --verify-object OBJECT_ID   # never overwrites owner.key
         (secret is typed at a hidden prompt; --secret-stdin for scripting. Keep kit and secret in different places.)
Options: --store DIR (default endcap_store)  --key FILE (default owner.key)
Never commit owner.key or any store directory.

Limits (pilot implementation settings, NOT protocol rules): max chunk 16 MiB, max 65,536 chunks, max archive 1 GiB.
Override with endcap.Limits(...) via the `limits=` argument; pass the SAME limits to verify()/retrieve() for such archives.
Known limitation: a hostile storage backend can still force large memory allocation (backend.get returns whole blobs).
Tests: tests/test_core.py (original suite), tests/test_hardening.py (limits, metadata validation, blob lengths), tests/test_recovery.py (recovery kit).
